package com.cg.beans;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class BankDetails {
	@Column(name="accnum")
	private int accountNo;
	@Column(name="bank_name")
	private String bankName;
	@Column(name="IFSC")
	private int bankIFSCCode;
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public int getBankIFSCCode() {
		return bankIFSCCode;
	}
	public void setBankIFSCCode(int bankIFSCCode) {
		this.bankIFSCCode = bankIFSCCode;
	}

}
