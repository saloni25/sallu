package com.cg.beans;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Employee {
	@Id
	@Column(name="emp_id")
	private int employeeId;
	@Column(name="fname")
	private String firstName;
	@Column(name="lname")
	private String lastName;
	@Column(name="mobno")
    private int mobileNo;
	@Column(name="pan_card")
    private int pancard;
	@Column(name="email")
    private int emailid;
	@Column(name="yearly_invest")
	private int yearlyInvestmentUnder80C;
	@Embedded
	private BankDetails bankDetails;
	@Embedded
	private Salary salary;
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getPancard() {
		return pancard;
	}
	public void setPancard(int pancard) {
		this.pancard = pancard;
	}
	public int getEmailid() {
		return emailid;
	}
	public void setEmailid(int emailid) {
		this.emailid = emailid;
	}
	public int getYearlyInvestmentUnder80C() {
		return yearlyInvestmentUnder80C;
	}
	public void setYearlyInvestmentUnder80C(int yearlyInvestmentUnder80C) {
		this.yearlyInvestmentUnder80C = yearlyInvestmentUnder80C;
	}
	public BankDetails getBankDetails() {
		return bankDetails;
	}
	public void setBankDetails(BankDetails bankDetails) {
		this.bankDetails = bankDetails;
	}
	public Salary getSalary() {
		return salary;
	}
	public void setSalary(Salary salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName="
				+ firstName + ", lastName=" + lastName + ", mobileNo="
				+ mobileNo + ", pancard=" + pancard + ", emailid=" + emailid
				+ ", yearlyInvestmentUnder80C=" + yearlyInvestmentUnder80C
				+ ", bankDetails=" + bankDetails + ", salary=" + salary + "]";
	}
}
