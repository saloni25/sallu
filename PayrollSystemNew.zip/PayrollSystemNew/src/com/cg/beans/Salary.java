package com.cg.beans;

import javax.persistence.Column;
import javax.persistence.Embeddable;
@Embeddable
public class Salary {
	@Column (name="basic_salary")
	private int Salary;
	@Column (name="hra")
	private int hra;
	@Column (name="ta")
	private int ta;
	@Column (name="da")
	private int da;
	@Column (name="company_pf")
	private int companypf;
	@Column (name="employee_pf")
	private int employeepf;
	@Column (name="gross_salary")
	private int grosssalary;
	@Column (name="monthly_tax")
	private int monthlytax;
	@Column (name="net_salary")
	private int netsalary;
	public int getSalary() {
		return Salary;
	}
	public void setSalary(int salary) {
		Salary = salary;
	}
	public int getHra() {
		return hra;
	}
	public void setHra(int hra) {
		this.hra = hra;
	}
	public int getTa() {
		return ta;
	}
	public void setTa(int ta) {
		this.ta = ta;
	}
	public int getDa() {
		return da;
	}
	public void setDa(int da) {
		this.da = da;
	}
	public int getCompanypf() {
		return companypf;
	}
	public void setCompanypf(int companypf) {
		this.companypf = companypf;
	}
	public int getEmployeepf() {
		return employeepf;
	}
	public void setEmployeepf(int employeepf) {
		this.employeepf = employeepf;
	}
	public int getGrosssalary() {
		return grosssalary;
	}
	public void setGrosssalary(int grosssalary) {
		this.grosssalary = grosssalary;
	}
	public int getMonthlytax() {
		return monthlytax;
	}
	public void setMonthlytax(int monthlytax) {
		this.monthlytax = monthlytax;
	}
	public int getNetsalary() {
		return netsalary;
	}
	public void setNetsalary(int netsalary) {
		this.netsalary = netsalary;
	}
}





