package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.beans.Employee;
import com.cg.service.IEmpService;


@Controller
public class EController {
	@Autowired
	IEmpService empservice;

	//add
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addData(@ModelAttribute("my")Employee emp)
	{
		return "addemployee";
	}
	@RequestMapping(value="putData",method=RequestMethod.POST)
	public  ModelAndView dataAdd(@ModelAttribute("my") Employee emp)
	{
		System.out.println("before entering data");
		int empId=empservice.insertData(emp);
		System.out.println("after entering data");
		//System.out.println(emp.getTraineeLocation());
		return new ModelAndView("success", "emps", empId);


	}
}
