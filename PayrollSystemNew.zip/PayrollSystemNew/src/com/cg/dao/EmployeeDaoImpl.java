package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.beans.Employee;

@Repository("empdao")
public class EmployeeDaoImpl implements IEmployeeDao{

	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public int insertData(Employee emp) {
		entitymanager.persist(emp);
		entitymanager.flush();
		return 0;
	}

}
