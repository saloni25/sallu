package com.cg.dao;

import com.cg.beans.Employee;

public interface IEmployeeDao {

	int insertData(Employee emp);

}
