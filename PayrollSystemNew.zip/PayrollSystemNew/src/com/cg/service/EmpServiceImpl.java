package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.Employee;
import com.cg.dao.IEmployeeDao;
@Service("empservice")
@Transactional
public class EmpServiceImpl implements IEmpService{

	@Autowired
	IEmployeeDao empdao;
	@Override
	public int insertData(Employee emp) {
		return empdao.insertData(emp);
		
	}

}
