package com.cg.service;

import com.cg.beans.Employee;

public interface IEmpService {
	public int insertData(Employee emp);

}
