package com.cg.springmvcone.service;

import java.util.List;

import com.cg.springmvcone.dto.Trainee;

public interface ITraineeService {
	public int insertData(Trainee trainee);
	public List<Trainee> ShowData();
	public void removeData(int traineeId);
    public List<Trainee> searchData(int traineeId);
	public void updateData(Trainee trainee);
}
