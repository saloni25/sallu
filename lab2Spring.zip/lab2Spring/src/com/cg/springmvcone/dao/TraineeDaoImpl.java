package com.cg.springmvcone.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import com.cg.springmvcone.dto.Trainee;

@Repository("traineedao")
public class TraineeDaoImpl implements ITraineeDao {
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public int insertData(Trainee trainee) {
		entityManager.persist(trainee);
		entityManager.flush();
		return trainee.getTraineeId();
	}

	@Override
	public List<Trainee> ShowData() {
		// TODO Auto-generated method stub
		Query queryOne=entityManager.createQuery("FROM Trainee");  //Trainee is the name of dto class not sql table
		List<Trainee> dataList=queryOne.getResultList();
		return dataList;
	}

	@Override
	public void removeData(int traineeId) {
		// TODO Auto-generated method stub

		Query queryThree = entityManager.createQuery("DELETE FROM Trainee WHERE traineeId=:trainee_id");
		//System.out.println("Dummy");
		queryThree.setParameter("trainee_id", traineeId);
		queryThree.executeUpdate();
	
	}

	@Override
	public List<Trainee> searchData(int traineeId) {
		// TODO Auto-generated method stub
		Query queryTwo=entityManager.createQuery("FROM Trainee "+ "WHERE traineeId=:trainee_id");
		queryTwo.setParameter("trainee_id",traineeId);
		List<Trainee> mySearch= queryTwo.getResultList();
		return mySearch;
	}

	@Override
	public void updateData(Trainee trainee) {
		// TODO Auto-generated method stub
		
		entityManager.merge(trainee);
		
//		Query queryFour = entityManager.createQuery("Update Trainee SET traineeName=:trainee_name, traineeLocation=:trainee_location, traineeDomain=:trainee_domain,  WHERE traineeId=:trainee_id");
//		queryFour.setParameter("trainee_id", trainee.getTraineeId());
//		queryFour.setParameter("trainee_name", trainee.getTraineeName());
//		queryFour.setParameter("trainee_location", trainee.getTraineeLocation());
//		queryFour.setParameter("trainee_domain", trainee.getTraineeDomain());
//		queryFour.executeUpdate();
	}
		
	}


